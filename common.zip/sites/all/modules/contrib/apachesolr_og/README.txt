
README for Apache Solr Organic Groups Integration

This module depends on Apache Solr Search Integration and adds additional 
information to the search index to enable group faceting, per group 
searching, etc.
