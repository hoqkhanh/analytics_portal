General third party connection module for Drupal that makes it easier to
enable users to one click login (and register) through connect-services like
Facebook Connect, Twitter Connect or whatever some crazy developer decides to
create a submodule for.

Still in it's early life and likely to need some love and attention.
Not feature complete, any help with extending and improving it is appreciated

/ Frans & VoxPelli